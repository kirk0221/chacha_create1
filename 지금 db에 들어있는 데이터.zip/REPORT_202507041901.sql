INSERT INTO CHACHA.REPORT (REPORT_ID,MEMBER_ID,SELLER_ID,REPORT_DATE,REPORT_TITLE,REPORT_TEXT) VALUES
	 (1,1,1,TIMESTAMP'2025-07-02 16:46:40','욕설 및 비방',TO_CLOB('사용자가 욕설을 포함한 메시지를 보냈습니다.')),
	 (2,2,2,TIMESTAMP'2025-07-02 16:46:40','허위 광고',TO_CLOB('상품 설명과 실제 상품이 다릅니다.')),
	 (3,3,3,TIMESTAMP'2025-07-02 16:46:40','악성 댓글',TO_CLOB('리뷰에 부적절한 댓글이 포함되어 있습니다.')),
	 (4,4,4,TIMESTAMP'2025-07-02 16:46:40','스팸 메시지',TO_CLOB('반복적인 광고 메시지를 보냈습니다.')),
	 (5,5,5,TIMESTAMP'2025-07-02 16:46:40','불량 제품',TO_CLOB('상품이 고장 난 상태로 도착했습니다.'));
