INSERT INTO CHACHA.TYPE_CATEGORY (TYPE_CATEGORY_ID,TYPE_CATEGORY_NAME) VALUES
	 (1,'뜨개질공예'),
	 (2,'금속공예'),
	 (3,'목공예'),
	 (4,'도자기공예'),
	 (5,'유리공예'),
	 (6,'가죽공예'),
	 (7,'레진공예'),
	 (8,'식물공예'),
	 (9,'양재공예'),
	 (10,'기타');
