INSERT INTO CHACHA.CART (CART_ID,MEMBER_ID,PRODUCT_ID,PRODUCT_CNT) VALUES
	 (17,1,5,7),
	 (2,2,2,1),
	 (3,3,3,3),
	 (4,4,4,1),
	 (5,5,5,5),
	 (16,1,6,5),
	 (22,1,4,1),
	 (23,1,1,1),
	 (24,1,3,1);
