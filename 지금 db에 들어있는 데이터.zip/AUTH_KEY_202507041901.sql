INSERT INTO CHACHA.AUTH_KEY (AUTH_KEY_NO,CODE,EMAIL,CREATE_TIME) VALUES
	 (1,'hGtxB6','kirk0221@naver.com',TIMESTAMP'2025-07-03 14:47:51'),
	 (2,'6Pa91h','dreamwlals@naver.com',TIMESTAMP'2025-07-03 16:22:57'),
	 (3,'c6KgT8','rlawlals1123@gmail.com',TIMESTAMP'2025-07-03 17:36:17'),
	 (4,'mvpQ06','yoonjung450@naver.com',TIMESTAMP'2025-07-04 17:37:00');
