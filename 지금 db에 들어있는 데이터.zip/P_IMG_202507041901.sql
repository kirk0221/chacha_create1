INSERT INTO CHACHA.P_IMG (P_IMG_ID,PRODUCT_ID,P_IMG_URL,P_IMG_ENUM,P_IMG_SEQ) VALUES
	 (1,1,'kakao.png','THUMBNAIL',1),
	 (2,1,'kakao.png','THUMBNAIL',2),
	 (3,2,'/resources/productImages/naver.png','THUMBNAIL',1),
	 (4,3,'prod3_thumb.jpg','THUMBNAIL',1),
	 (5,4,'65ef1bda-eecb-4e8b-b613-10e2081e3095.jpg','THUMBNAIL',1),
	 (6,6,'1bd6c232-d276-41e8-9718-30efd5936927.jpg','THUMBNAIL',1),
	 (7,6,'/resources/productImages/61218330-392c-435e-90f1-1f6511d5598e.jpg','THUMBNAIL',2),
	 (8,6,'/resources/productImages/4725183f-d956-44c7-9210-8bb75657c466.jpeg','THUMBNAIL',3),
	 (43,24,'d854d37a-09a4-4fda-94e0-10bd30851248.jpg','THUMBNAIL',1),
	 (44,24,'61f2a9d1-5788-4158-98b4-71405fd935b9.jpg','THUMBNAIL',2);
INSERT INTO CHACHA.P_IMG (P_IMG_ID,PRODUCT_ID,P_IMG_URL,P_IMG_ENUM,P_IMG_SEQ) VALUES
	 (45,26,'4725183f-d956-44c7-9210-8bb75657c466.jpeg','THUMBNAIL',1),
	 (12,8,'/resources/productImages/3475e75d-1c33-470d-b129-50dc13c86b76.jpg','THUMBNAIL',1),
	 (13,8,'/resources/productImages/23b0d3a8-c6a0-4bf0-b710-808f8aa6001f.jpg','THUMBNAIL',2),
	 (14,8,'/resources/productImages/b03ecb7f-505d-4d92-b4ed-83a715ba15b4.jpg','THUMBNAIL',3),
	 (15,9,'/resources/productImages/06040f53-3e49-4dcb-95ee-cac2797a58dc.jpg','THUMBNAIL',1),
	 (16,9,'/resources/productImages/8d3594bb-6956-47d2-8530-b87ed2f5fa2f.jpg','THUMBNAIL',2),
	 (17,9,'/resources/productImages/1f311d3f-1182-4009-8cf6-b11b06786f9b.jpg','THUMBNAIL',3),
	 (18,10,'/resources/productImages/2b03a44f-4cd5-422a-977b-b823bdd008b2.jpg','THUMBNAIL',1),
	 (19,10,'/resources/productImages/7a1cca95-7762-4268-a75d-1d3c4d62f542.jpg','THUMBNAIL',2),
	 (20,10,'/resources/productImages/ea46e1b9-312f-401a-bc63-cbeca108ceff.jpg','THUMBNAIL',3);
INSERT INTO CHACHA.P_IMG (P_IMG_ID,PRODUCT_ID,P_IMG_URL,P_IMG_ENUM,P_IMG_SEQ) VALUES
	 (21,11,'/resources/productImages/21e82a06-d247-4550-bc9d-1accd7231e86.jpg','THUMBNAIL',1),
	 (22,11,'/resources/productImages/5c0f742e-4a69-4e49-b772-e282446d7068.jpg','THUMBNAIL',2),
	 (23,11,'/resources/productImages/28522774-0f6a-42e2-8681-bf2f2cf41fac.jpg','THUMBNAIL',3),
	 (24,12,'/resources/productImages/287a33a0-c01b-4aa4-99f9-284c0f0442ab.jpg','THUMBNAIL',1),
	 (25,12,'/resources/productImages/c28be7a9-1d40-46e0-b467-3eaa936536ce.jpg','THUMBNAIL',2),
	 (26,12,'/resources/productImages/65ef1bda-eecb-4e8b-b613-10e2081e3095.jpg','THUMBNAIL',3),
	 (27,21,'newproduct1.jpg','THUMBNAIL',1),
	 (46,26,'naver.png','THUMBNAIL',2),
	 (47,26,'kakao.png','THUMBNAIL',3),
	 (48,27,'49b6ff82-b488-4fb4-9600-44062b21c505.png','THUMBNAIL',1);
INSERT INTO CHACHA.P_IMG (P_IMG_ID,PRODUCT_ID,P_IMG_URL,P_IMG_ENUM,P_IMG_SEQ) VALUES
	 (49,27,'5d0f26d0-1dbd-481b-8245-7888f87c1329.jpg','THUMBNAIL',2),
	 (56,4,'28522774-0f6a-42e2-8681-bf2f2cf41fac.jpg','THUMBNAIL',2),
	 (41,24,'0e037dbb-ce54-4af9-91f2-55365fe70fe0.jpg','THUMBNAIL',3),
	 (51,28,'12296f04-3809-4514-99e8-8b7a43843999.jpg','THUMBNAIL',1),
	 (52,28,'61934253-2613-4a4c-ba8d-9a41995531cd.jpeg','THUMBNAIL',2),
	 (53,28,'59ee1551-30ec-42c7-8d20-980455461f6a.jpg','THUMBNAIL',3),
	 (54,27,'cc008615-188c-42ee-8975-871b24d0d4f8.png','THUMBNAIL',3),
	 (62,21,'4725183f-d956-44c7-9210-8bb75657c466.jpeg','THUMBNAIL',2),
	 (64,29,'1f311d3f-1182-4009-8cf6-b11b06786f9b.jpg','THUMBNAIL',1),
	 (65,29,'28522774-0f6a-42e2-8681-bf2f2cf41fac.jpg','THUMBNAIL',2);
INSERT INTO CHACHA.P_IMG (P_IMG_ID,PRODUCT_ID,P_IMG_URL,P_IMG_ENUM,P_IMG_SEQ) VALUES
	 (66,30,'cc008615-188c-42ee-8975-871b24d0d4f8.png','THUMBNAIL',1),
	 (67,30,'5d0f26d0-1dbd-481b-8245-7888f87c1329.jpg','THUMBNAIL',2),
	 (68,30,'59ee1551-30ec-42c7-8d20-980455461f6a.jpg','THUMBNAIL',3),
	 (69,31,'1f311d3f-1182-4009-8cf6-b11b06786f9b.jpg','THUMBNAIL',1),
	 (70,31,'5c0f742e-4a69-4e49-b772-e282446d7068.jpg','THUMBNAIL',2);
