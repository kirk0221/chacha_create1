INSERT INTO CHACHA.D_CATEGORY (D_CATEGORY_ID,U_CATEGORY_ID,D_CATEGORY_NAME) VALUES
	 (1,1,'상의'),
	 (2,1,'하의'),
	 (3,1,'가방'),
	 (4,1,'지갑'),
	 (5,1,'기타(목도리, 모자, 벨트, 등)'),
	 (6,2,'디퓨저,캔들'),
	 (7,2,'무드등'),
	 (8,2,'꽃,식물'),
	 (9,2,'가구'),
	 (10,3,'반지');
INSERT INTO CHACHA.D_CATEGORY (D_CATEGORY_ID,U_CATEGORY_ID,D_CATEGORY_NAME) VALUES
	 (11,3,'팔찌'),
	 (12,3,'목걸이'),
	 (13,3,'키링'),
	 (14,4,'비누'),
	 (15,4,'그릇'),
	 (16,4,'식기류'),
	 (17,4,'컵'),
	 (18,4,'케이스'),
	 (19,5,'향수'),
	 (20,5,'인형');
INSERT INTO CHACHA.D_CATEGORY (D_CATEGORY_ID,U_CATEGORY_ID,D_CATEGORY_NAME) VALUES
	 (21,5,'반려동물'),
	 (22,5,'문구');
