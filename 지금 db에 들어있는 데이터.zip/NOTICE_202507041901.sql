INSERT INTO CHACHA.NOTICE (NOTICE_ID,STORE_ID,NOTICE_CHECK,NOTICE_TITLE,NOTICE_TEXT,NOTICE_DATE) VALUES
	 (1,1,0,'시스템 점검 안내',TO_CLOB('2025년 6월 30일 00시부터 06시까지 시스템 점검이 진행됩니다.'),TIMESTAMP'2025-07-02 16:46:40'),
	 (2,2,1,'신규 이벤트 안내',TO_CLOB('7월 한달간 특별 할인 이벤트를 진행합니다.'),TIMESTAMP'2025-07-02 16:46:40'),
	 (3,3,0,'배송 지연 안내',TO_CLOB('일부 지역 배송이 지연되고 있습니다.'),TIMESTAMP'2025-07-02 16:46:40'),
	 (4,4,1,'서비스 이용약관 변경',TO_CLOB('서비스 이용약관이 일부 변경되었습니다.'),TIMESTAMP'2025-07-02 16:46:40'),
	 (5,5,1,'회원 혜택 안내',TO_CLOB('신규 회원 가입 시 5,000원 쿠폰을 드립니다.'),TIMESTAMP'2025-07-02 16:46:40');
