INSERT INTO CHACHA."MEMBER" (MEMBER_ID,MEMBER_EMAIL,MEMBER_NAME,MEMBER_PWD,MEMBER_PHONE,MEMBER_REGI,JOIN_DATE) VALUES
	 (1,'user1@example.com','홍길동1','asdf1234!','010-1111-1111','REG001',TIMESTAMP'2025-01-01 00:00:00'),
	 (2,'user2@example.com','홍길동2','pwd2','010-2222-2222','REG002',TIMESTAMP'2025-01-02 00:00:00'),
	 (3,'user3@example.com','홍길동3','pwd3','010-3333-3333','REG003',TIMESTAMP'2025-01-03 00:00:00'),
	 (4,'user4@example.com','홍길동4','pwd4','010-4444-4444','REG004',TIMESTAMP'2025-01-04 00:00:00'),
	 (5,'user5@example.com','홍길동5','pwd5','010-5555-5555','REG005',TIMESTAMP'2025-01-05 00:00:00'),
	 (9,'rlawlals1123@gmail.com','김지민테스트임','chacha1111!','010-2622-2754','011203-4',TIMESTAMP'2025-07-03 17:37:51'),
	 (7,'kirk0221@naver.com','차민건','ckalsrjs11**','010-9236-7674','000221-3',TIMESTAMP'2025-07-03 14:48:28'),
	 (8,'dreamwlals@naver.com','김지민','chacha0000!','010-2622-2754','011203-4',TIMESTAMP'2025-07-03 16:24:53'),
	 (10,'yoonjung450@naver.com','최윤정','yj21372137*','010-3924-2137','011121-4',TIMESTAMP'2025-07-04 17:39:10');
