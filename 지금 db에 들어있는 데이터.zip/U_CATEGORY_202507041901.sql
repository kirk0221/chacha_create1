INSERT INTO CHACHA.U_CATEGORY (U_CATEGORY_ID,U_CATEGORY_NAME) VALUES
	 (1,'패션잡화'),
	 (2,'인테리어 소품'),
	 (3,'악세서리'),
	 (4,'생활잡화'),
	 (5,'기타');
